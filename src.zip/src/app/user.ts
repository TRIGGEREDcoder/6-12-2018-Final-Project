export interface User {
    firstName:string;
	lastName:string;
	dob:string;
	emailId:string;
	gender:string;
	password:string;
}