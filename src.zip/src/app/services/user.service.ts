import { Injectable } from '@angular/core';
import { User } from '../user';
import { HttpClient, HttpErrorResponse, HttpParams} from  '@angular/common/http';
import { Observer, observable, throwError } from 'rxjs';
import {Observable} from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import {Http,Response} from '@angular/http';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private httpClient:HttpClient) { }

  private registerUserUrl:string = 'http://localhost:4444/register'
  private loginUserUrl:string='http://localhost:4444/login'


  public registerUser(user:User):Observable<string>{
    let body = JSON.parse(JSON.stringify(user))
    return this.httpClient.post<string>(this.registerUserUrl, body).pipe(catchError(this.handleError));
  }

  public loginUser(emailId:string, password:string):Observable<string>{
    let params = new HttpParams();
    params = params.set('emailId',emailId);
    params = params.set('password',password);
    let body = JSON.parse(JSON.stringify(params))
    return this.httpClient.post<string>(this.loginUserUrl,body).pipe(catchError(this.handleError));
  }

  public getUser(emailId:string){
    let params = new HttpParams()
    params=params.set("emailId",emailId)
    return this.httpClient.get<User>("http://localhost:4444/getUserId",{params:params}).pipe(catchError(this.handleError))
  }

  private handleError(error:any){
    if(error instanceof ErrorEvent){
      console.error('1 An ErrorEvent occured :',error.error.message);
      return throwError(error.error.message);
    }else if(error instanceof HttpErrorResponse){
      console.error(`2 Backend returned code ${error.status}, body was : ${error.message}`);
      return throwError(`Backend returned code ${error.status}, body was : ${error.message}`);
    }
    else if(error instanceof TypeError){
      console.error(`3 Backend returned code ${error.message}, body was : ${error.stack}`);
       return throwError(`Backend returned code ${error.message}, body was : ${error.stack}`);
    }
  }
}